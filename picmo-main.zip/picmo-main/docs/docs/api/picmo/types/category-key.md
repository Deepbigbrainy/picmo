# `CategoryKey`

Uniquely identifies one of the supported emoji categories.

- `activities`
- `animals-nature`
- `custom`
- `flags`
- `food-drink`
- `objects`
- `people-body`
- `recents`
- `smileys-emotion`
- `symbols`
- `travel-places`
