# `DataStoreFactory`

A function that returns a data store implementation.

<pre>
type DataStoreFactory = (locale: <a href="https://emojibase.dev/api/emojibase#Locale">Locale</a>) => <a href="../classes/data-store">DataStore</a>;
</pre>