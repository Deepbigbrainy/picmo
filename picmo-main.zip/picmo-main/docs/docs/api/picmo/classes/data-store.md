# `DataStore`

Abstract base class for data stores.

A data store contains all emoji data for the picker.

PicMo ships with two `DataStore` implementations:

- [`IndexedDBStore`](./indexed-db-store)
- [`InMemoryStore`](./in-memory-store)

