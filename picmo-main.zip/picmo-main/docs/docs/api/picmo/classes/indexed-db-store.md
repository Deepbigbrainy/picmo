# `IndexedDBStore`

Store implementation that uses a local IndexedDB database.

This is the preferred method, and is the default if no data store factory is specified.
