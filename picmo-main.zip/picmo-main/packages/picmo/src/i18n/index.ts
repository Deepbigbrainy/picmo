export { default as en } from './lang-en';
