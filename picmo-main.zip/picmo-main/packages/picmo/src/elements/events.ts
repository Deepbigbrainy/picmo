export type SearchEvent = CustomEvent<string>;
