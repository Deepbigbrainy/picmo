export default {
  injectStyles: true
};
